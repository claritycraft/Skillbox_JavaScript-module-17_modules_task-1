import { navigateTo } from './router.js';

document.addEventListener('DOMContentLoaded', () => {
  // При загрузке сразу показываем список
  navigateTo('list');
});