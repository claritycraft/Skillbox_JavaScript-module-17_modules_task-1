export function loadItems() {
    try {
      return JSON.parse(localStorage.getItem('items')) || [];
    } catch {
      return [];
    }
  }

  export function saveItems(items) {
    localStorage.setItem('items', JSON.stringify(items));
  }

  export function deleteItem(index) {
    const items = loadItems();
    items.splice(index, 1);
    saveItems(items);
  }
