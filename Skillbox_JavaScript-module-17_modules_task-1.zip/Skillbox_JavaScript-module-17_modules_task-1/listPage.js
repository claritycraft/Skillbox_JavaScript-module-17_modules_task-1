import { loadItems, deleteItem } from './storage.js';
import { navigateTo } from './router.js';

export function renderListPage(container) {
  // 🔁 Добавим заголовок и кнопку
  const header = document.getElementById('header');
  header.innerHTML = `
    <div class="header-container">
      <h1 class="header-title">Склад</h1>
      <button id="nav-add" class="button-add">Добавить запись</button>
    </div>
  `;

  document.getElementById('nav-add').addEventListener('click', () => navigateTo('add'));

  // 🧹 Очищаем контейнер
  container.innerHTML = '';

  const table = document.createElement('table');
  table.id = 'itemTable';
  table.innerHTML = `
    <thead>
      <tr class="table-list">
        <th class="table-list_items" onclick="sortTable(0)">Название</th>
        <th class="table-list_items" onclick="sortTable(1)">Полка</th>
        <th class="table-list_items" onclick="sortTable(2)">Вес</th>
        <th class="table-list_items" onclick="sortTable(3)">Время хранения</th>
        <th class="table-list_items">Действие</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  container.appendChild(table);

  const tbody = table.querySelector('tbody');
  const items = loadItems();

  if (!items.length) {
    const row = document.createElement('tr');
    row.innerHTML = `<td colspan="5">Нет данных</td>`;
    tbody.appendChild(row);
    return;
  }

  items.forEach((item, index) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${item.name}</td>
      <td>${item.shelf}</td>
      <td>${item.weight}</td>
      <td>${item.expiry}</td>
      <td><button class="table-list_button">Удалить</button></td>
    `;
    row.querySelector('button').onclick = () => {
      deleteItem(index);
      renderListPage(container);
    };
    tbody.appendChild(row);
  });

  window.sortTable = function (index) {
    const rows = Array.from(tbody.querySelectorAll('tr'));
    rows.sort((a, b) =>
      a.children[index].textContent.localeCompare(b.children[index].textContent)
    );
    tbody.innerHTML = '';
    rows.forEach(row => tbody.appendChild(row));
  };
}
