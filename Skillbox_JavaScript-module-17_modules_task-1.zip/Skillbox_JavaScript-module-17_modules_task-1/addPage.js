import { loadItems, saveItems } from './storage.js';
import { navigateTo } from './router.js';

export function renderAddPage(container) {
  document.getElementById('header').innerHTML = '';
  container.innerHTML = `
    <h2 class="header-title">Добавить запись</h2>
    <form id="addForm" class="form">
      <input class="form-input" type="text" id="name" placeholder="Название" required />
      <input class="form-input" type="text" id="shelf" placeholder="Полка" required />
      <input class="form-input" type="number" id="weight" placeholder="Вес" required />
      <input class="form-input" type="date" id="expiry" placeholder="Время хранения" required />
      <button class="form-button" type="submit">Добавить</button>
    </form>
  `;

  const form = container.querySelector('#addForm');
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = form.name.value.trim();
    const shelf = form.shelf.value.trim();
    const weight = form.weight.value.trim();
    const expiry = form.expiry.value;

    if (name && shelf && weight && expiry) {
      const items = loadItems();
      items.push({ name, shelf, weight, expiry });
      saveItems(items);
      navigateTo('list');
    } else {
      alert('Заполните все поля');
    }
  });
}
