// export async function navigateTo(page) {
//     const app = document.getElementById('app');
//     app.innerHTML = '';
//     showPreloader(true);

//     if (page === 'list') {
//       const { renderListPage } = await import('./listPage.js');
//       renderListPage(app);
//     } else if (page === 'add') {
//       const { renderAddPage } = await import('./addPage.js');
//       renderAddPage(app);
//     }

//     showPreloader(false);
//   }

//   function showPreloader(show) {
//     const preloader = document.getElementById('preloader');
//     preloader.style.display = show ? 'flex' : 'none';
//   }

export async function navigateTo(page) {
  const app = document.getElementById('app');
  app.innerHTML = '';

  showPreloader(true);

  // Ждём минимум 1 секунды
  await delay(1000);

  if (page === 'list') {
    const { renderListPage } = await import('./listPage.js');
    renderListPage(app);
  } else if (page === 'add') {
    const { renderAddPage } = await import('./addPage.js');
    renderAddPage(app);
  }

  showPreloader(false);
}

function showPreloader(show) {
  const preloader = document.getElementById('preloader');
  preloader.style.display = show ? 'flex' : 'none';
}

// Задержка
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
